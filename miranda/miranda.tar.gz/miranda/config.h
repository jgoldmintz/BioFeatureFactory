/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you have the erand48 function.  */
#define HAVE_ERAND48 1

/* Define if you have the lrand48 function.  */
#define HAVE_LRAND48 1

/* Define if you have the memset function.  */
#define HAVE_MEMSET 1

/* Define if you have the srand48 function.  */
#define HAVE_SRAND48 1

/* Define if you have the strchr function.  */
#define HAVE_STRCHR 1

/* Define if you have the strdup function.  */
#define HAVE_STRDUP 1

/* Define if you have the strstr function.  */
#define HAVE_STRSTR 1

/* Define if you have the <malloc.h> header file.  */
#define HAVE_MALLOC_H 1

/* Define if you have the <strings.h> header file.  */
#define HAVE_STRINGS_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Name of package */
#define PACKAGE "miRanda"

/* Version number of package */
#define VERSION "1.9"

/* avoid warning about unused variables */
#define UNUSED __attribute__ ((unused))

/* only for gcc */
#define UNUSED __attribute__ ((unused))

